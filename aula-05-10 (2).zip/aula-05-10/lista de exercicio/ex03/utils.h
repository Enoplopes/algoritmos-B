string gerarEmail(string nomeCompleto){
    string primeiro = nomeCompleto.substr(0. nomeCompleto.find(" "));

    string ultimo = nomeCompleto.substr(nome.rfind(" ") + 1);
    
    return primeiro + "." + ultimo + "@ufn.edu.br";
}