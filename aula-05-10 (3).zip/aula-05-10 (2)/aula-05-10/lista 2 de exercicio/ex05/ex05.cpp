#include <iostream>

using namespace std;

#include "utils.h"

int main(){
    int vetor[5] = {1, 2, 3, 4, 5};

    if (verificarOrdenado(vetor, 5)){
        cout << "O vetor esta ordenado (true).";
    } else {
        cout << "O vetor esta desordenado (false).";
    }

    return 1;
}