#include <iostream>
#include <string>

using namespace std;

#include "utils.h"

int main(){
    string frase;

    cout << "Digite uma frase: ";
    getline(cin, frase);

    cout << "A quantidade de vogais eh: " << contarVogais(frase);

    return 1;
}