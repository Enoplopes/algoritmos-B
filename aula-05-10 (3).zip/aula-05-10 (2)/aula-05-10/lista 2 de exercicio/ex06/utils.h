string retornarPrimeiroNome(string nomeCompleto) {
    int espaco = nomeCompleto.find(" ");
    if (espaco == -1) {
        return nomeCompleto;
    }
    return nomeCompleto.substr(0, espaco);
}