#include <ctime>
#include <iostream>
#include <vector>

using namespace std;

void exibirVetor(vector<int> v) {
    for (size_t i = 0; i < v.size(); i++) {
        cout << v[i] << "\t";
    }
    cout << "\n\n";
}

void popularVetor(vector<int> &v, int qtd, int inicio, int fim) {
    int numero;
    for (int i = 0; i < qtd; i++) {
        numero = inicio + (rand() % (fim - inicio + 1));
        v.push_back(numero);
    }
}

// 2) Método exercicio2: armazena os números comuns no vetorResultado passado por referência
void exercicio2(vector<int> vetorA, vector<int> vetorB, vector<int> &vetorResultado) {
    for (size_t i = 0; i < vetorA.size(); i++) {
        for (size_t j = 0; j < vetorB.size(); j++) {
            if (vetorA[i] == vetorB[j]) {
                // Evita duplicar o mesmo valor caso apareça repetido
                bool jaExiste = false;
                for (size_t k = 0; k < vetorResultado.size(); k++) {
                    if (vetorResultado[k] == vetorA[i]) {
                        jaExiste = true;
                        break;
                    }
                }
                if (!jaExiste) {
                    vetorResultado.push_back(vetorA[i]);
                }
            }
        }
    }
}

int main() {
    srand(time(NULL));

    vector<int> vetorA;
    vector<int> vetorB;
    vector<int> vetorResultado;

    popularVetor(vetorA, 10, 1, 20);
    popularVetor(vetorB, 10, 1, 20);

    cout << "Vetor A:\n";
    exibirVetor(vetorA);

    cout << "Vetor B:\n";
    exibirVetor(vetorB);

    // Chama o exercicio2 passando o vetorResultado por referência
    exercicio2(vetorA, vetorB, vetorResultado);

    cout << "Vetor Resultado (com os numeros em comum):\n";
    exibirVetor(vetorResultado);

    return 0;
}