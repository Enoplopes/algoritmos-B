bool validarData(string data) {
    if (data.length() == 10){
        return true;
    } else {
        return false;
    }

}