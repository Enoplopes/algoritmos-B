#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

// Função para separar a linha usando a vírgula como delimitador
vector<string> split(string frase, string delimitador = ",") {
    vector<string> resultado;
    int inicio = 0;
    int fim = frase.find(delimitador);
    
    while (fim != -1) {
        resultado.push_back(frase.substr(inicio, fim - inicio));
        inicio = fim + delimitador.size();
        fim = frase.find(delimitador, inicio);
    }
    resultado.push_back(frase.substr(inicio, fim - inicio));

    return resultado;
}

// Estrutura para armazenar os dados de inflação
typedef struct {
    string mes;
    float valor;
} Inflacao;

int main() {
    vector<Inflacao> vetorInflacao;
    Inflacao tmp;

    // 1. Abre o arquivo na mesma pasta do executável/código
    ifstream arquivo("inflacao.csv");

    // 2. Verifica se abriu corretamente
    if (!arquivo.is_open()) {
        cerr << "Erro: O arquivo 'inflacao.csv' não foi encontrado na pasta!" << endl;
        return 1;
    }

    string linha;
    
    // 3. Lê o arquivo linha por linha
    while (getline(arquivo, linha)) {
        if (linha.empty()) continue; // Pula linhas vazias

        vector<string> vetorPalavras = split(linha, ",");

        if (vetorPalavras.size() >= 2) {
            tmp.mes = vetorPalavras[0];
            tmp.valor = stof(vetorPalavras[1]); // Converte string para float
            vetorInflacao.push_back(tmp);
        }
    }

    // 4. Fecha o arquivo
    arquivo.close();

    // 5. Mostra os dados na tela
    cout << "--- Dados Carregados com Sucesso ---" << endl;
    for (size_t i = 0; i < vetorInflacao.size(); i++) {
        cout << "Mes: " << vetorInflacao[i].mes << " | Inflacao: " << vetorInflacao[i].valor << endl;
    }

    return 0;
}