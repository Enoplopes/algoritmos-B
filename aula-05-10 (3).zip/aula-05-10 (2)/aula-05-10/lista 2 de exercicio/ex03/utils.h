int contarVogais(string frase) {
    int qtd = 0;
    for (int i = 0; i < frase.length(); i++) {
        char c = tolower(frase[i]);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            qtd++;
        }
    }
    return qtd;
}