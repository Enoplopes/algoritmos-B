bool validarCpf(string cpf) {
    if (cpf.length() == 11){
        return true;
    } else {
        return false;
    }

}