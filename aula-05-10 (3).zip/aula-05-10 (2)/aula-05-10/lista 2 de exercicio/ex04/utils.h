string converterMaiuscula(string frase) {
    string resultado = frase;
    for (int i = 0; i < resultado.length(); i++) {
        resultado[i] = toupper(resultado[i]);
    }
    return resultado;
}