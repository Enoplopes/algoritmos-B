typedef struct {
    string nome;
    float altura;   //metros
    float peso;     //kilos
    float imc;
} IndiceMassaCorporal;