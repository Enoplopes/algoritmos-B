#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main(){
    vector<int> vetor;
    cout << "ola turma de algoritmos!" << endl;
    int opcao;
    string valor;
    do{
        cout << "digite o valor do elemnto: " << vetor.size() + 1 << ": ";
        getline(cin, valor);
        vetor.push_back(valor);
        fflush(stdin); // limpa o buffer de entrada

        cout << "deseja adicionar outro elemento? (1 - sim, 0 - Nao): ";
        cin >> opcao;
    } while (opcao == 1);

    for(int i = 0; i < vetor.size(); i++){
        cout << "o valor do elemnto " << i + 1 << " eh: " << vetor[i] << endl;
}



    return 1;
}