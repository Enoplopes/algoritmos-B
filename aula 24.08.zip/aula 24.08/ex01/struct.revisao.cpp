#include <iostream>
#include <string>
#include <vector>



using namespace std;

#include "meusTipos.h"

int main() {

    IndiceMassaCorporal pessoaTMP;

    pessoaTMP.nome = "alexandre Zamberlan";
    pessoaTMP.altura = 1.88;
    pessoaTMP.peso = 90.4;

    cout << "nome:  " << pessoaTMP.nome <<  endl;
    cout << "altura (m): " << pessoaTMP.altura < endl;
    cout << "peso (kg): " << pessoaTMP.peso << endl;

    float imc = pessoaTMP.peso / (pessoaTMP.altura * pessoaTMP.altura);

    cout << "IMC: " imc << endl;
  





    return 1;
}