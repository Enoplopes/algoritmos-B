#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TAMANHO 10


 
int main() {
    int opcao;
    int vetor [TAMANHO];
    int qtd_elementos = 0;

    srand (time(NULL));


    do {
        system("cls");
        printf("MENU PRINCIPAL\n");
        printf("1 - Popular vetor com numeros aleatorios\n");
        printf("2 - Listar vetor populado\n");
        printf("3 - Sair\n");
        printf("Opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("Populando o vetor com numeros aleatorios\n");
                for (int i = 0; i < TAMANHO; i++) {
                    vetor[i] = rand() % 100;
                    qtd_elementos++;
                }
                break;
            case 2:
                printf("Listando o vetor com numeros aleatorios\n");
                if(qtd_elementos > 0){
                for (int i = 0; i < TAMANHO; i++) {
                    printf("%d\t", vetor[i]);
                }
                printf ("\n");
            }
                else {
                    printf("vetor vazio. Nada a exibir\n");
                }

                
                break;
            case 3:
                printf("Sistema encerrado\n");
                break;
            default:
                printf("Opcao invalida. Redigite\n");
                break;
        }
        system("pause");
    } while (opcao != 3);

    return 1;
}