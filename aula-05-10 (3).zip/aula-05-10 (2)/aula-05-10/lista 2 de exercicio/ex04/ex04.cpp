#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

#include "utils.h"

int main(){
    string frase;

    cout << "Digite uma frase: ";
    getline(cin, frase);

    cout << "Frase em maiuscula: " << converterMaiuscula(frase);

    return 1;
}