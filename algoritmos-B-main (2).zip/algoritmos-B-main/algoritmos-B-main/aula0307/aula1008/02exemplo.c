#include <stdio.h>
#include <stdlib.h>

#define TAMANHO 4

int main(){
    char *vetor[TAMANHO];
    char palavra[100];

    printf("ola turma de algoritmos\n");
    for(int i = 0; i < TAMANHO; i++){
        printf("Digite a %d palavra: ", i + 1):
        scanf("%s", palavra);
        strcpy(vetor[i], palavra);
    }
    for(int i = 0; i < TAMANHO; i++){
        printf("a palavra do elemento %d eh: ", i + 1, vetor[i]);
    }


    return 1;
}