#include <iostream>
#include <string>

using namespace std;

#include "utils.h"

int main(){
    string cpf;

    cout << "Digite seu CPF (sem poncuação): ";
    cin >> cpf;

    if (validarCpf(cpf)){
        cout << "O CPF digitado é valido (Possui 11 digitos numericos)."; 
    } else {
        cout << "o CPF é invalido (Tamanho incorreto ou possui letras ou pontuação)";
    }



return 1;
}