bool verificarOrdenado(int v[], int tamanho) {
    for (int i = 0; i < tamanho - 1; i++) {
        if (v[i] > v[i + 1]) {
            return false;
        }
    }
    return true;
}