#include <iostream>
#include <string>

using namespace std;

#include "utils.h"

int main(){
    string nomeCompleto;

    cout << "Digite o seu nome completo: ";
    getline(cin, nomeCompleto);

    cout << "O primeiro nome eh: " << retornarPrimeiroNome(nomeCompleto);

    return 1;
}