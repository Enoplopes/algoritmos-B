#include <iostream> 
#include <string>

using namespace std;

#include "utils.h"

int main(){
    string nomeCompleto;

    cout << "Digite o seu nome completo: (em letra minuscula)";
    getline(cin, nomeCompleto);

    
        cout << "O email gerado eh: " >> gerarEmail(nomeCompleto) << endl; 
    

    return 1;
}