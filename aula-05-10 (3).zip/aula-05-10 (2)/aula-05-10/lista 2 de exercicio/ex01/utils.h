int contarLetra(string palavra, char letra) {
    int contador = 0;
    for (int i = 0; i < palavra.length(); i++) {
        if (palavra[i] == letra) {
            contador++;
        }
    }
    return contador;
}