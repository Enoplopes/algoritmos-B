void validarData(string dia, string mes, string ano) {
    // Exemplo simples baseado no seu estilo de verificação de string
    if (dia.length() > 0 && mes.length() > 0 && ano.length() == 4) {
        cout << "DATA VÁLIDA";
    } else {
        cout << "DATA INVÁLIDA";
    }
}