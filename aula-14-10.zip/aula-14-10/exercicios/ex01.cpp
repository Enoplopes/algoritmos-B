#include <ctime>
#include <iostream>
#include <vector>

using namespace std;

void exibirVetor(vector<int> v) {
    for (size_t i = 0; i < v.size(); i++) {
        cout << v[i] << "\t";
    }
    cout << "\n\n";
}

void popularVetor(vector<int> &v, int qtd, int inicio, int fim) {
    int numero;
    for (int i = 0; i < qtd; i++) {
        numero = inicio + (rand() % (fim - inicio + 1));
        v.push_back(numero);
    }
}

// 1) Método exercicio1: sem retorno, apenas exibe os números que aparecem nos dois vetores
void exercicio1(vector<int> vetorA, vector<int> vetorB) {
    cout << "Numeros que aparecem nos dois vetores:\n";
    bool encontrou = false;
    
    for (size_t i = 0; i < vetorA.size(); i++) {
        for (size_t j = 0; j < vetorB.size(); j++) {
            if (vetorA[i] == vetorB[j]) {
                cout << vetorA[i] << "\t";
                encontrou = true;
                break;
            }
        }
    }
    if (!encontrou) {
        cout << "Nenhum valor em comum encontrado.";
    }
    cout << "\n\n";
}

int main() {
    srand(time(NULL));

    vector<int> vetorA;
    vector<int> vetorB;

    popularVetor(vetorA, 10, 1, 20);
    popularVetor(vetorB, 10, 1, 20);

    cout << "Vetor A:\n";
    exibirVetor(vetorA);

    cout << "Vetor B:\n";
    exibirVetor(vetorB);

    exercicio1(vetorA, vetorB);

    return 0;
}