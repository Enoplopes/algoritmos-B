#include <iostream>
#include <string>

using namespace std;

#include "utils.h"

int main(){
    string palavra;
    char letra;

    cout << "Digite uma palavra: ";
    cin >> palavra;

    cout << "Digite uma letra: ";
    cin >> letra;

    int qtd = contarLetra(palavra, letra);

    cout << "A letra '" << letra << "' aparece " << qtd << " vezes na palavra.";

    return 1;
}