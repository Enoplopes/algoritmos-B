#include <iostream>
#include <string>

using namespace std;

#include "utils.h"

int main(){
    string data;

    cout << "Digite a data (no formato dd/mm/aaaa): ";
    cin >> data;

    if (validarDsata(data)){
        cout << "a data digitado é valida (Possui 10 caracteres)."; 
    } else {
        cout << "a data é invalida (tamanho invalido, nao possui 10 caracteres)";
    }


    return 1;
}