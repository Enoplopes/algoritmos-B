typedef struct {
    string placa;
    string cor;
    string horaEntrada;
} Veiculo;
